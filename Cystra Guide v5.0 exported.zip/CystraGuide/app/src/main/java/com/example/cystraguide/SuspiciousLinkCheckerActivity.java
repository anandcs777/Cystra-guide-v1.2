package com.example.cystraguide;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.net.URL;

public class SuspiciousLinkCheckerActivity extends AppCompatActivity
{
    String url;
    EditText linkInput;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suspicious_link_checker);

        linkInput = (EditText) findViewById(R.id.linkinput);
        button = (Button) findViewById(R.id.button);
    }

    public void checkLink(View view)
    {
        url = linkInput.getText().toString();
        Log.i("Link",url);
        boolean isValid;

        try
        {
            new URL(url).toURI();
            isValid = true;
        }
        catch (Exception e)
        {
            isValid = false;
        }

        if (isValid)
        {
            alertDialog("The URL is Valid");
        }
        else
        {
            alertDialog("The URL is Invalid");
        }
    }

    private void alertDialog(String msg)
    {
        AlertDialog.Builder dialog=new AlertDialog.Builder(this);
        dialog.setMessage(msg);
        dialog.setTitle("Dialog Box");
        dialog.setNeutralButton("OK", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                // Dismissed
            }
        });
        AlertDialog alertDialog=dialog.create();
        alertDialog.show();
    }
}