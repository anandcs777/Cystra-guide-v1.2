package com.example.cystraguide;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import com.github.barteksc.pdfviewer.PDFView;

public class DocumentActivity extends AppCompatActivity
{
    // Declaring PDFView globally
    PDFView pdfView;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_document);

        // Getting data passed from previous activity
        Intent intent = getIntent();
        String appName = intent.getStringExtra("app");
        Toast.makeText(this, appName, Toast.LENGTH_SHORT).show();

        // Finding PDFView with its ID
        pdfView = findViewById(R.id.pdfView);

        // Switch statement for opening different documents according to the list item
        switch(appName)
        {
            case "Facebook":
                showDocument("facebook.pdf");
                break;
            case "Instagram":
                showDocument("instagram.pdf");
                break;
            case "WhatsApp":
                showDocument("whatsapp.pdf");
                break;
            case "Signal":
                showDocument("signal.pdf");
                break;
            case "Telegram":
                showDocument("telegram.pdf");
                break;
            case "Discord":
                showDocument("discord.pdf");
                break;
            default:
                showDocument("pdf_example.pdf");
        }
    }

    // Method for opening the document
    public void showDocument(String appName)
    {
        pdfView.fromAsset(appName)
                .enableDoubletap(true)
                .defaultPage(0)
                .enableAntialiasing(true)
                .load();
    }
}