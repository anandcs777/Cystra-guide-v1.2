package com.example.cystraguide;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.widget.TextView;

public class PermissionsListActivity extends AppCompatActivity
{
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permissions_list);

        textView = (TextView) findViewById(R.id.textView);
        Intent intent = getIntent();
        String[] permissions = intent.getStringArrayExtra("permissions");
        String text;

        if(permissions != null)
        {
            text = "PERMISSIONS: \n\n";
            for (int i = 0; i < permissions.length; i++)
            {
                text += permissions[i].substring(19).replace('_',' ') + "\n";
            }
        }
        else
        {
            text = "This application requires no permissions to run";
        }

        textView.setText(text);
        textView.setMovementMethod(new ScrollingMovementMethod());

    }
}