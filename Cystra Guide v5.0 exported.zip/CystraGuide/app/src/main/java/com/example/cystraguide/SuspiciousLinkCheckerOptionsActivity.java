package com.example.cystraguide;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class SuspiciousLinkCheckerOptionsActivity extends AppCompatActivity
{
    // Declaring buttons for 4 sub-modules globally
    public Button button1; //Basic URL Checker
    public Button button2; //Norton SafeWeb
    public Button button3; //URL Void
    public Button button4; //More Information

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suspicious_link_checker_options);

        // Finding 4 buttons with their respective ID's
        button1 = (Button) findViewById(R.id.button1);
        button2 = (Button) findViewById(R.id.button2);
        button3 = (Button) findViewById(R.id.button3);
        button4 = (Button) findViewById(R.id.button4);
    }

    public void basicUrlChecker(View view)
    {
        Log.i("Info","Basic URL Checker");
        Intent intent= new Intent(getApplicationContext(),SuspiciousLinkCheckerActivity.class);
        startActivity(intent);
    }

    public void nortonSafeWeb(View view)
    {
        Log.i("Info","Norton Safe Web");
        Intent intent= new Intent(getApplicationContext(),WebActivity.class);
        intent.putExtra("option",8);
        startActivity(intent);
    }

    public void urlVoid(View view)
    {
        Log.i("Info","URL Void");
        Intent intent= new Intent(getApplicationContext(),WebActivity.class);
        intent.putExtra("option",9);
        startActivity(intent);
    }

    public void moreInformation(View view)
    {
        Log.i("Info","More Information");
        Intent intent= new Intent(getApplicationContext(),WebActivity.class);
        intent.putExtra("option",10);
        startActivity(intent);
    }
}