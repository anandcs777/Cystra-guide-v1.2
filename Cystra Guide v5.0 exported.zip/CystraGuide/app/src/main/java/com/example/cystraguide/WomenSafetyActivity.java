package com.example.cystraguide;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class WomenSafetyActivity extends AppCompatActivity
{
    // Declaring buttons for 4 sub-modules globally
    public Button button1; //Filing a Complaint
    public Button button2; //Track Status
    public Button button3; //Guidelines
    public Button button4; //Resources

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_women_safety);

        // Finding 4 buttons with their respective ID's
        button1 = (Button) findViewById(R.id.button1);
        button2 = (Button) findViewById(R.id.button2);
        button3 = (Button) findViewById(R.id.button3);
        button4 = (Button) findViewById(R.id.button4);
    }

    public void fileComplaint(View view)
    {
        Log.i("Info","File a Complaint");
        Intent intent= new Intent(getApplicationContext(),WebActivity.class);
        intent.putExtra("option",4);
        startActivity(intent);
    }

    public void trackStatus(View view)
    {
        Log.i("Info","Track Status");
        Intent intent= new Intent(getApplicationContext(),WebActivity.class);
        intent.putExtra("option",5);
        startActivity(intent);
    }

    public void guidelines(View view)
    {
        Log.i("Info","Guidelines");
        Intent intent= new Intent(getApplicationContext(),WebActivity.class);
        intent.putExtra("option",6);
        startActivity(intent);
    }

    public void resources(View view)
    {
        Log.i("Info","Resources");
        Intent intent= new Intent(getApplicationContext(),WebActivity.class);
        intent.putExtra("option",7);
        startActivity(intent);
    }
}