package com.example.cystraguide;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.content.Intent;

public class CyberSecurityNewsActivity extends AppCompatActivity
{
    // Declaring buttons for 3 sub-modules globally
    public Button button1; //Report Status And Records
    public Button button2; //Latest Cyber News
    public Button button3; //Report Or Verify News

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cyber_security_news);

        // Finding 3 buttons with their respective ID's
        button1 = (Button) findViewById(R.id.button1);
        button2 = (Button) findViewById(R.id.button2);
        button3 = (Button) findViewById(R.id.button3);
    }

    // Method called to open a WebView when Report Status And Records button is touched
    public void reportStatusAndRecords(View view)
    {
        Log.i("Info","Report Status And Reports");
        Intent intent= new Intent(getApplicationContext(),WebActivity.class);
        intent.putExtra("option",1);
        startActivity(intent);
    }

    // Method called to open a WebView when Latest Cyber News button is touched
    public void latestCyberNews(View view)
    {
        Log.i("Info","Latest Cyber News");
        Intent intent= new Intent(getApplicationContext(),WebActivity.class);
        intent.putExtra("option",2);
        startActivity(intent);
    }

    // Method called to open a WebView when Report Or Verify News button is touched
    public void reportOrVerifyNews(View view)
    {
        Log.i("Info","Report Or Verify News");
        Intent intent= new Intent(getApplicationContext(),WebActivity.class);
        intent.putExtra("option",3);
        startActivity(intent);
    }
}