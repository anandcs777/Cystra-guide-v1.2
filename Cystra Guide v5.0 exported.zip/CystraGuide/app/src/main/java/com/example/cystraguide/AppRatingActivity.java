package com.example.cystraguide;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;
import java.util.ArrayList;

public class AppRatingActivity extends AppCompatActivity
{
    // Declaring global variables used below
    SearchView searchView;
    ListView listView;
    ArrayList<String> apps;
    ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_rating);

        // Finding SearchView and ListView with their respective ID's
        searchView = (SearchView) findViewById(R.id.searchView);
        listView = (ListView) findViewById(R.id.listView);

        // Defining ArrayList to store ListView items
        apps = new ArrayList<>();
        apps.add("Facebook");
        apps.add("Instagram");
        apps.add("WhatsApp");
        apps.add("Signal");
        apps.add("Telegram");
        apps.add("Discord");

        // ArrayAdapter for putting items in ArrayList to ListView
        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, apps);
        listView.setAdapter(arrayAdapter);

        // When an item in the ListView is touched
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                // Leads to a new activity which shows a document
                Intent intent = new Intent(getApplicationContext(), DocumentActivity.class);
                intent.putExtra("app",apps.get(position));
                startActivity(intent);
            }
        });

        // When the search bar is used
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener()
        {
            @Override
            public boolean onQueryTextSubmit(String query)
            {
                if(apps.contains(query))
                {
                    arrayAdapter.getFilter().filter(query);
                }
                else
                {
                    Toast.makeText(AppRatingActivity.this, "No Match Found",Toast.LENGTH_LONG).show();
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText)
            {
                arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });
    }
}