package com.example.cystraguide;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class AppPermissionOrRatingActivity extends AppCompatActivity
{
    // Declaring buttons for 2 sub-modules globally
    public Button button1; //Report Status And Records
    public Button button2; //Latest Cyber News

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_permission_or_rating);

        // Finding 2 buttons with their respective ID's
        button1 = (Button) findViewById(R.id.button1);
        button2 = (Button) findViewById(R.id.button2);
    }

    // Method called to open a ListView when App Rating button is touched
    public void appRating(View view)
    {
        Log.i("Info","App Rating");
        Intent intent= new Intent(getApplicationContext(),AppRatingActivity.class);
        startActivity(intent);
    }

    // Method called to open a ListView when Installed App Permissions button is touched
    public void installedAppPermissions(View view)
    {
        Log.i("Info","Installed App Permissions");
        Intent intent= new Intent(getApplicationContext(),InstalledAppPermissionsActivity.class);
        startActivity(intent);
    }
}