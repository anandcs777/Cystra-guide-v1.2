package com.example.cystraguide;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity
{
    // Declaring buttons for 4 modules globally
    public ImageButton button1; //Cyber Security News
    public ImageButton button2; //Women Safety
    public ImageButton button3; //App Rating
    public ImageButton button4; //Suspicious Link Checker

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Finding 4 buttons with their respective ID's
        button1 = (ImageButton) findViewById(R.id.imageButton1);
        button2 = (ImageButton) findViewById(R.id.imageButton2);
        button3 = (ImageButton) findViewById(R.id.imageButton3);
        button4 = (ImageButton) findViewById(R.id.imageButton4);
    }

    // Method called to open new activity when Cyber Security News button is touched
    public void cyberSecurityNews(View view)
    {
        Log.i("Info","Cyber Security News");
        Intent intent= new Intent(MainActivity.this,CyberSecurityNewsActivity.class);
        startActivity(intent);
    }

    // Method called to open new activity when Women Safety button is touched
    public void womenSafety(View view)
    {
        Log.i("Info","Women Safety");
        Intent intent= new Intent(MainActivity.this,WomenSafetyActivity.class);
        startActivity(intent);
    }

    // Method called to open new activity when App Rating button is touched
    public void appRating(View view)
    {
        Log.i("Info","App Rating");
        Intent intent= new Intent(MainActivity.this,AppPermissionOrRatingActivity.class);
        startActivity(intent);
    }

    // Method called to open new activity when Suspicious Link Checker button is touched
    public void suspiciousLinkChecker(View view)
    {
        Log.i("Info","Suspicious Link Checker");
        Intent intent= new Intent(MainActivity.this,SuspiciousLinkCheckerOptionsActivity.class);
        startActivity(intent);
    }
}