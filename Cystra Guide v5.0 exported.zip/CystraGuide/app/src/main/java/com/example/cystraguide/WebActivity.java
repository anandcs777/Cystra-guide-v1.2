package com.example.cystraguide;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class WebActivity extends AppCompatActivity
{
    // Declaring WebView globally
    public WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);

        // Getting data passed from previous activity
        Intent intent = getIntent();
        int option = intent.getIntExtra("option",0);

        // Defining WebView
        webView = (WebView) findViewById(R.id.myWebView);
        WebSettings webSettings= webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        switch(option)
        {
            case 1:
                // When Report Status And Records button is touched
                webView.loadUrl("https://cystraguide.blogspot.com/p/report-status.html");
                break;
            case 2:
                // When Latest Cyber News button is touched
                webView.loadUrl("https://cystraguide.blogspot.com/");
                break;
            case 3:
                // When Report Or Verify News button is touched
                webView.loadUrl("https://docs.google.com/forms/d/e/1FAIpQLSfmVe5f5iv0pJpFym1cKHs20Ii_sv1b_zDTuXuYOpI7L5QXIw/viewform?usp=sf_link");
                break;
            case 4:
                // When File A Complaint button is touched
                webView.loadUrl("https://cybercrime.gov.in/Webform/Crime_ReportAnonymously.aspx");
                break;
            case 5:
                // When Track Status button is touched
                webView.loadUrl("https://cybercrime.gov.in/Webform/Crime_AuthoLogin.aspx?rnt=1");
                break;
            case 6:
                // When Guidelines button is touched
                webView.loadUrl("https://cybercrime.gov.in/Webform/Crime_OnlineSafetyTips.aspx");
                break;
            case 7:
                // When Resources button is touched
                webView.loadUrl("https://cystraguide.blogspot.com/p/women-safety-and-awareness.html");
                break;
            case 8:
                // When Norton SafeWeb button is touched
                webView.loadUrl("https://safeweb.norton.com/");
                break;
            case 9:
                // When URL Void button is touched
                webView.loadUrl("https://www.urlvoid.com/");
                break;
            case 10:
                // When More Information button is touched
                webView.loadUrl("https://cystraguide.blogspot.com/p/suspicious-link-checker_29.html");
                break;
            default:
                // By Default opens Home Page of CystraGuide blogspot
                webView.loadUrl("https://cystraguide.blogspot.com/");
        }

        webView.setWebViewClient(new WebViewClient());
    }
}